<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="get" action="practical5_14(result).php">
        <input type="text" name="sid" placeholder="delete_by_rollno">
        <input type="submit" value="delete">
    </form>
    <strong>The data is already deleted if you want to know the result first go the previous practical and add the data</strong> 
</body>
</html>